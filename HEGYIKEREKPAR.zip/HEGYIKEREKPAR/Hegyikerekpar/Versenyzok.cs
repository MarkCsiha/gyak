﻿public class Versenyzok
{
    public string Rajtszam { get; set; }
    public string Kategoria { get; set; }
    public string Nev {  get; set; }
    public string? Egyesulet { get; set; }
    public TimeSpan Ido {  get; set; }

    public string Versenytav => new Versenytav(Rajtszam).Tav;

    public override string ToString() =>
        $"\tRajtszám: {Rajtszam} \n" +
        $"\tNév: {Nev} \n" +
        $"{(Egyesulet is null ? null : $"\tEgyesület: {Egyesulet}\n")}" +
        $"\tIdő: {Ido} \n";




    public Versenyzok(string sor)
    {
        var v = sor.Split(';');
        Rajtszam = v[0];
        Kategoria = v[1];
        Nev = v[2];
        Egyesulet = string.IsNullOrEmpty(v[3]) ? null : v[3];
        Ido = TimeSpan.Parse(v[4]);
       
    }
}

