﻿using System.Text;

List<Versenyzok> versenyzok = [];
const int IndulokSzama = 691;

using StreamReader sr = new("..\\..\\..\\resources\\bukkm2019.txt", Encoding.UTF8);
_ = sr.ReadLine();
while (!sr.EndOfStream) versenyzok.Add(new(sr.ReadLine()!));

foreach (var v in versenyzok)
{
    Console.WriteLine(v + "\n----------------------------------------------------------------------------");
}

Console.WriteLine($"4. feladat: A versenytávot nem teljesítők: {100 - (versenyzok.Count / (float)IndulokSzama * 100):0.00}");

int f5 = versenyzok.Count(v => v.Versenytav == "Rövid" && v.Kategoria[^1] == 'n');

Console.WriteLine($"5. feladat: a rövid távon versenyző női versenyzők száma: {f5} fő");

bool f6 = versenyzok.Any(v => v.Ido.TotalHours > 6);

Console.WriteLine($"6. feladat: {(f6 ? "volt" : "nem volt")} olyan versenyző aki 6 óránál többet töltött a pályán");

var f7 = versenyzok

    .Where(v => v.Rajtszam[0] == 'R' && v.Kategoria == "ff")

    .MinBy(v => v.Ido);

Console.WriteLine($"7. feladat: a felnőtt férfiak között a rövid távú verseny győztese: \n{f7}");

var f8 = versenyzok

    .Where(v => v.Kategoria[^1] == 'f')

    .GroupBy(v => v.Kategoria)

    .OrderBy(g => g.Key);

Console.WriteLine($"8. feladat: férfi indulók száma kategóriánként:");

foreach (var g in f8)

{

    Console.WriteLine($"\t{g.Key,-4} - {g.Count(),3} fő");

}


