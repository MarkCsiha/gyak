﻿using Etelek;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Unicode;

const string Forras = "C:\\Users\\csiha.mark\\Desktop\\Etelek\\Etelek\\resources\\etelek.csv";

const string FileWrite = "C:\\Users\\csiha.mark\\Desktop\\Etelek\\Etelek\\resources\\frissensultek.txt";

List<Etel> kajak = [];

using StreamReader sr = new(Forras);

while (!sr.EndOfStream)
{
    Etel e = new Etel(sr.ReadLine());
    kajak.Add(e);
}

Console.WriteLine($"Ételek száma: {kajak.Count}");

var f2 = kajak.Any(k => k.Nehezseg == "könnyű" && k.Perc > 60).ToString();
Console.WriteLine(f2);

var f3 = kajak.Count(k => k.Nehezseg == "közepes" && k.Perc <= 20);
Console.WriteLine(f3);

var f4 = kajak.Average(k => k.Perc);
Console.WriteLine($"{f4:0.00}");

var f5 = kajak.Where(k => k.Kategoria == "édesség")
              .Sum(k => Convert.ToDouble(k.Perc));
Console.WriteLine(f5 / 60);

List<Etel> kategorialista = [];
Console.Write("Kategória név: ");
string bekeres = Console.ReadLine();

var f6 = kajak.Where(k => k.Kategoria == bekeres);

if (f6.Any())
{
    foreach (var e in f6)
    {
        Console.WriteLine(e.Nev);
    }
}
else
{
    Console.WriteLine("Ember, most jövök a templomból!");
}

var etelCsoportok = kajak.GroupBy(k => k.Kategoria)
                         .ToDictionary(k => k.Key, k => k.Count());
foreach (var e in etelCsoportok)
{
    Console.WriteLine($"\t{e.Key} -- {e.Value} \n");
}

var f8 = kajak.Where (k => k.Nehezseg == "közepes")
               .MinBy(k => k.Perc)
               ;

Console.WriteLine(f8);

using StreamWriter sw = new(FileWrite, append: false, Encoding.UTF8);
sw.WriteLine("Étel neve;Elkészítési ideje;Kategóriája;Nehézsége");
var kaja = kajak.Where(k => k.Kategoria == "frissensült");
foreach (var k in kaja)
{
    sw.WriteLine($"{k.Nev}  {k.Kategoria}  {k.Perc}");
}