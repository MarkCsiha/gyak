﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Etelek
{
    internal class Etel
    {
        //        //adattagok rendre:
        //- étel neve
        //- elkészítési idő percben
        //- kategória
        //- elkészítési nehézség(könnyű, közepes vagy nehéz)
        public string Nev { get; set; }
        public int Perc { get; set; }
        public string Kategoria { get; set; }
        public string Nehezseg { get; set; }

        public override string ToString() =>

            $"\tNév: {Nev} \n" +
            $"\tIdő (percben): {Perc}   \n" +
            $"\tKategória: {Kategoria}   \n" +
            $"\tNehézség: {Nehezseg}   \n";

        public Etel(string sor) 
        {
            var v = sor.Split(';');
            Nev = v[0];
            Perc = int.Parse(v[1]);
            Kategoria = v[2];
            Nehezseg = v[3];
        }
    }
}
