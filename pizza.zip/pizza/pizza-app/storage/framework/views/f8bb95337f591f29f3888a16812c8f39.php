<?php $__env->startSection('content'); ?>

    <main class="container py-3">
        <h1 class="text-center display-5"><?php echo e($result->nev); ?></h1>
        <p><?php echo e($result->feltet); ?></p>
        <p><b>
            <?php if($result->akcios == 0): ?>
                Ez a pizza nem akciós - talán a jövőhéten az lesz!
            <?php else: ?>
            Ez a pizza most a készlet erejéig akciós! - mínusz 10%
            <?php endif; ?>
        </b></p>
    </main>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\pizza\pizza-app\resources\views/adatlap.blade.php ENDPATH**/ ?>