<?php $__env->startSection('content'); ?>
    <main class="container py-3">
        <h1 class="text-center display-5">Akciós pizzák</h1>
        <div class="row">
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <a href="/adatlap/<?php echo e($row->id); ?>"><h2><?php echo e($row->nev); ?></h2></a>
                    <p><?php echo e($row->feltet); ?></p>
                    <p><b>Akciós (24 cm)</b><br>
                        <s><?php echo e($row->ar); ?>Ft</s> helyett <span class="text-danger"><b><?php echo e($row->ar*0.9); ?> Ft</b></span>
                     </p>
                     <p class="text-end">
                        <a href="/osszes">További méretek</a>
                     </p>
                     <hr>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div:class>
    </main>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\csiha.mark\Desktop\pizza\pizza-app\resources\views/welcome.blade.php ENDPATH**/ ?>