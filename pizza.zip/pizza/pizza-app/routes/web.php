<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PizzaController;

//Route::get('/', function () {
    //return view('welcome');
//});

Route::get('/', [PizzaController::class, "Welcome"]);
Route::get('/osszes', [PizzaController::class, "Osszes"]);
Route::get('/random-pizza', [PizzaController::class, "Random"]);

Route::get('/adatlap/{id}', [PizzaController::class, "Adatlap"]);
