<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class pizzak extends Model
{
    protected $table = "pizzak";
}
