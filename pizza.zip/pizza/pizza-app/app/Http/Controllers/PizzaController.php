<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pizzak;

class PizzaController extends Controller
{
    public function Welcome(){
        return view("welcome", [
            "result"    => pizzak::where("akcios", "=", 1)
                                   ->get()
        ]);
    }

    public function Osszes(){
        //return view("osszes");
    }

    public function Random(){}

    public function Adatlap($id){
        return view("adatlap", [
            "result"    =>pizzak::find($id)
        ]);
    }
}
