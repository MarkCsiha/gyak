@extends('layout')
@section('content')
    <main class="container py-3">
        <h1 class="text-center display-5">Akciós pizzák</h1>
        <div class="row">
            @foreach ($result as $row)
                <div class="col-md-4">
                    <a href="/adatlap/{{ $row->id }}"><h2>{{ $row->nev}}</h2></a>
                    <p>{{$row->feltet }}</p>
                    <p><b>Akciós (24 cm)</b><br>
                        <s>{{ $row->ar}}Ft</s> helyett <span class="text-danger"><b>{{ $row->ar*0.9 }} Ft</b></span>
                     </p>
                     <p class="text-end">
                        <a href="/osszes">További méretek</a>
                     </p>
                     <hr>
                </div>
            @endforeach
        </div:class>
    </main>
    @endsection
</body>
</html>