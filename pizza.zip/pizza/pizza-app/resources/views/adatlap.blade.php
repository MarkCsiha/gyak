@extends('layout')
@section('content')
{{--@dd($result)--}}
    <main class="container py-3">
        <h1 class="text-center display-5">{{$result->nev}}</h1>
        <p>{{ $result->feltet}}</p>
        <p><b>
            @if ($result->akcios == 0)
                Ez a pizza nem akciós - talán a jövőhéten az lesz!
            @else
            Ez a pizza most a készlet erejéig akciós! - mínusz 10%
            @endif
        </b></p>
        <p>Árak: </p>
        @if($result->akcios == 0)
        <ul>
            <li>24 cm: {{$result->ar}} Ft</li>
            <li>32 cm: {{$result->ar * 1.25}} Ft</li>
            <li>45 cm: {{$result->ar * 1.50}} Ft</li>
        </ul>
        @else

        @endif
    </main>

    @endsection